import React, { useEffect, useState, useMemo } from 'react';
import { useParams, useHistory } from 'react-router-dom';
import { 
  IonPage, IonContent, IonHeader, IonToolbar, IonTitle, 
  IonButtons, IonBackButton, IonSpinner, IonButton, IonIcon, IonToast
} from '@ionic/react';
import { checkmarkDoneOutline } from 'ionicons/icons';
import { useActsStore } from '../../store/actsStore';
import { useAuthStore } from '../../store/authStore';
import { useInvoiceStore } from '../../store/invoiceStore'; 
import { invoicesApi } from '../../api/invoicesApi'; 
import { ACT_TEMPLATES } from '../../features/acts/configs/registry';
import { GenericForm } from '../../features/acts/components/GenericForm';
import { normalizeInvoice } from '../../domain/normalizers';

export const FinalActPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const history = useHistory();
  const token = useAuthStore(s => s.token);
  
  const { saveAct, clearCurrentAct } = useActsStore();
  const invoiceFromStore = useInvoiceStore(s => s.list.find(i => i.id === id));
  
  const [fetchedInvoice, setFetchedInvoice] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [showToast, setShowToast] = useState(false);

  // Используем шаблон 'work_completed'
  const template = ACT_TEMPLATES['work_completed']; 

  useEffect(() => {
    clearCurrentAct();
  }, []);

  // Грузим заявку (с обработкой ошибок)
  useEffect(() => {
    const hasData = invoiceFromStore || fetchedInvoice;
    if (!hasData && token && id) {
        setLoading(true);
        invoicesApi.fetchAll(token).then(data => {
            if (Array.isArray(data)) {
                const found = data.find((i:any) => i.id === id);
                if(found) setFetchedInvoice(found);
            }
        }).finally(() => setLoading(false));
    }
  }, [invoiceFromStore, fetchedInvoice, token, id]);

  const cleanInvoice = useMemo(() => {
      const raw = invoiceFromStore || fetchedInvoice;
      return raw ? normalizeInvoice(raw) : null;
  }, [invoiceFromStore, fetchedInvoice]);

  // АВТОЗАПОЛНЕНИЕ
  const initialData = useMemo(() => {
      if (!cleanInvoice) return null;

      return {
          act_number: `FIN-${cleanInvoice.number}`,
          act_date: new Date().toISOString().split('T')[0],
          type: 'work_completed',
          
          lic: cleanInvoice.lic || '',
          owner_name: cleanInvoice.client_name || '',
          owner_phone: cleanInvoice.phone || '',
          object_address: cleanInvoice.addressText || '',
          
          work_description: cleanInvoice.service || 'Работы выполнены в полном объеме',
          amount: 0,
          warranty: '12',
          
          technician_name: 'Слесарь СТГО',
          technician_signature: '',
          owner_signature: '',
          photo_result: ''
      };
  }, [cleanInvoice]);

  const handleSave = async (data: any) => {
    if (!token) return;
    
    // Очистка данных
    const cleanSignature = (sig: any) => (sig && sig.length > 20) ? sig : ""; 

    // 🔥 ПЛОСКАЯ СТРУКТУРА ДЛЯ СЕРВЕРА
    // Мы отправляем всё в одном объекте, без вложенности details
    const payload = {
        invoice_id: id,
        type: 'work_completed',
        
        act_number: data.act_number,
        act_date: data.act_date,
        
        // Маппинг полей
        executor_name: data.technician_name || "Не указан",
        executor_position: 'Слесарь', 
        executor_signature: cleanSignature(data.technician_signature),

        client_name: data.owner_name || "Не указан",
        address: data.object_address || "",
        client_signature: cleanSignature(data.owner_signature),
        
        // Специфичные поля
        work_description: data.work_description || "",
        amount: Number(data.amount) || 0,
        warranty: String(data.warranty || ""),
        photo_result: cleanSignature(data.photo_result),
        
        notes: '',
        quality_assessment: 'Удовлетворительно',

        // Добавляем старые поля на всякий случай (для совместимости)
        lic: data.lic,
        owner_name: data.owner_name,
        technician_name: data.technician_name
    };

    console.log("🚀 Sending FLAT Payload:", payload);

    try {
        // saveAct обычно кладет всё в body. Если на бэкенде ActCompletedData плоская, это сработает.
        const result = await saveAct(token, payload);
        
        if (result && (result.id || result.success)) {
            console.log("✅ Saved success:", result);
            setIsSaved(true);
            setShowToast(true);
        } else {
            console.error("❌ Save failed (null result). Payload:", payload);
            alert('Ошибка: Сервер разорвал соединение. Попробуйте без фото/подписи.');
        }
    } catch (e: any) {
        console.error("❌ Save Exception:", e);
        alert(`Сбой сети: ${e.message}`);
    }
  };

  const handleCloseInvoice = async () => {
      if (!token) return;
      if (!window.confirm("Вы уверены, что хотите закрыть заявку?")) return;

      try {
          await invoicesApi.closeInvoice(token, id);
          alert("Заявка успешно закрыта!");
          history.replace('/app/invoices');
      } catch (e) {
          console.error(e);
          alert("Не удалось закрыть заявку");
      }
  };

  const showForm = !loading && template && initialData;

  return (
    <IonPage>
      <IonHeader className="ion-no-border">
        <IonToolbar>
          <IonButtons slot="start"><IonBackButton defaultHref={`/app/invoices/${id}/acts`} text="" color="dark" /></IonButtons>
          <IonTitle>Завершение</IonTitle>
        </IonToolbar>
      </IonHeader>
      
      <IonContent fullscreen style={{'--background': '#f7fafc'}}>
         {loading && (
             <div className="ion-padding ion-text-center" style={{marginTop: '50px'}}>
                 <IonSpinner />
                 <p style={{color: '#888'}}>Загрузка...</p>
             </div>
         )}

         {!loading && !template && (
             <div className="ion-padding ion-text-center" style={{marginTop: '20px', color: 'red'}}>
                 Ошибка: Шаблон 'work_completed' не найден.
             </div>
         )}

         {showForm && (
             <div style={{padding: '16px', paddingBottom: '120px'}}>
                 <GenericForm 
                    key="final-act-form"
                    template={template} 
                    initialData={initialData} 
                    onSave={handleSave} 
                 />
             </div>
         )}

         {isSaved && (
             <div style={{position: 'fixed', bottom: '30px', left: '16px', right: '16px', zIndex: 1001}}>
                 <IonButton 
                    expand="block" color="success" onClick={handleCloseInvoice}
                    style={{height: '56px', fontWeight: 'bold', '--border-radius': '14px', '--box-shadow': '0 8px 20px rgba(72, 187, 120, 0.4)'}}
                 >
                    <IonIcon slot="start" icon={checkmarkDoneOutline} />
                    ЗАКРЫТЬ ЗАЯВКУ
                 </IonButton>
             </div>
         )}

         <IonToast isOpen={showToast} message="Акт сохранен! Теперь закройте заявку." duration={3000} onDidDismiss={() => setShowToast(false)} color="primary"/>
      </IonContent>
    </IonPage>
  );
};